<?php
session_start();
include '../config/koneksi.php';

// Pastikan hanya pengguna yang sudah login yang dapat mengakses halaman ini
if ($_SESSION['status'] != 'login') {
    echo "<script>
    alert('Anda belum Login!');
    location.href='../index.php';
    </script>";
}

// Ambil userid dari sesi yang sedang aktif
$userid = $_SESSION['userid'];

// Ambil data pengguna dari database berdasarkan userid
$sql = mysqli_query($koneksi, "SELECT * FROM user WHERE userid='$userid'");
if(mysqli_num_rows($sql) > 0) {
    $row = mysqli_fetch_assoc($sql);
    $username = $row['username'];
    $namalengkap = $row['namalengkap'];
    $email = $row['email'];
    $alamat = $row['alamat'];
} else {
    // Jika data pengguna tidak ditemukan, redirect ke halaman login
    echo "<script>
    alert('Data pengguna tidak ditemukan!');
    location.href='../index.php';
    </script>";
    exit();
}

// Proses update data pengguna
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_namalengkap = $_POST['namalengkap'];
    $new_email = $_POST['email'];
    $new_alamat = $_POST['alamat'];

    // Query untuk update data pengguna
    $update_query = "UPDATE user SET namalengkap='$new_namalengkap', email='$new_email', alamat='$new_alamat' WHERE userid='$userid'";
    
    // Eksekusi query
    if (mysqli_query($koneksi, $update_query)) {
        echo "<script>
        alert('Data pengguna berhasil diperbarui!');
        location.href='../admin/profil.php';
        </script>";
    } else {
        echo "<script>
        alert('Terjadi kesalahan saat memperbarui data pengguna. Silakan coba lagi!');
        </script>";
    }
}
?>
