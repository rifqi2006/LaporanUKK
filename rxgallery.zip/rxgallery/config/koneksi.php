<?php
$hostname = 'localhost';
$userdb = 'root';
$passdb = '';
$namedb = 'db_gallery';

$koneksi = mysqli_connect($hostname, $userdb, $passdb, $namedb);
?>