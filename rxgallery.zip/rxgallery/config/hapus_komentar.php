<?php
// pastikan bahwa request yang diterima adalah POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // periksa apakah parameter komentarid tersedia dalam request
    if (isset($_POST['komentarid'])) {
        // mengambil komentarid dari request
        $komentarid = $_POST['komentarid'];

        // lakukan koneksi ke database
        include '../config/koneksi.php';

        // hapus komentar dari database berdasarkan komentarid
        $query = "DELETE FROM komentarfoto WHERE komentarid = ?";
        $statement = mysqli_prepare($koneksi, $query);
        mysqli_stmt_bind_param($statement, "i", $komentarid);
        $result = mysqli_stmt_execute($statement);

        // periksa apakah penghapusan berhasil
        if ($result) {
            // kirim respons sukses ke klien
            http_response_code(200);
            echo json_encode(array("message" => "Komentar berhasil dihapus."));
        } else {
            // kirim respons gagal ke klien
            http_response_code(500);
            echo json_encode(array("message" => "Gagal menghapus komentar. Silakan coba lagi."));
        }

        // tutup statement dan koneksi database
        mysqli_stmt_close($statement);
        mysqli_close($koneksi);
    } else {
        // jika parameter komentarid tidak tersedia, kirim respons dengan kode status 400 (Bad Request)
        http_response_code(400);
        echo json_encode(array("message" => "Parameter komentarid diperlukan."));
    }
} else {
    // jika request bukan POST, kirim respons dengan kode status 405 (Method Not Allowed)
    http_response_code(405);
    echo json_encode(array("message" => "Metode tidak diizinkan."));
}
?>
