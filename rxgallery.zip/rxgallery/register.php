<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>WEBSITE GALERI FOTO</title>
		<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
		<link rel="stylesheet" href="assets/css/style.css">

		<!-- google fonts -->
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Modern+Antiqua&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Princess+Sofia&display=swap" rel="stylesheet">
	</head>
	<body>
		<nav class="navbar navbar-expand-lg shadow">
			<div class="container">
				<a class="navbar-brand" href="index.php"> 
					<p class="Judulnav my-auto">Rx Galleria</p>
				</a>
					<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
				<div class="collapse navbar-collapse mt-2" id="navbarNavAltMarkup">
					<div class="navbar-nav me-auto"></div>
				</div>
				<!-- kalau ingin menambahkan sesuatu diujung  -->
			</div>
		</nav>
		
		<div class="container py-5">
			<div class="row justify-content-center">
				<div class="col-md-4">
					<div class="card">
						<div class="card-body">
							<div class="text-center">
								<h5 class="text-white">Registerasi Akun</h5>
							</div>
							<form action="config/aksi-registrasi.php" method="POST">
								<label class="form-label">Username</label>
								<input type="text" name="username" class="form-control" placeholder="Username" required>
								<label class="form-label">Password</label>
								<input type="password" name="password" class="form-control" placeholder="Password" required>
								<label class="form-label">Email</label>
								<input type="email" name="email" class="form-control" placeholder="Email" required>
								<label class="form-label">Nama Lengkap</label>
								<input type="text" name="namalengkap" class="form-control" placeholder="Nama Lengkap" required>
								<label class="form-label">Tanggal Lahir</label>
								<input type="date" name="date" class="form-control" required>
								<label class="form-label">Alamat</label>
								<input type="text" name="alamat" class="form-control" placeholder="Alamat" required>
								<div class="d-grid mt-2">
									<button class="btndaftar p-1 mt-1 rounded-2 fw-medium" type="submit" name="kirim">Daftar</button>
								</div>
							</form>
							<hr>
							<p class="text-center text-white">Sudah punya akun? <a href="login.php">Login Disini!</a></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<footer class="text-center border-top pb-1 pt-4 bg-light fixed-bottom">
		<p> Rx Galleria &copy; Reserved</p>
		</footer>
		<script type="text/javascript" src="assets/css/bootstrap.min.css"></script>
	</body>
</html>