<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=initial-scale=1.0">
    <!-- googefonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <!-- css -->
    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Document</title>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary mb-5 shadow-sm">
  <div class="container">
    <a class="navbar-brand" href="#">
      <img src="assets/img/logo.png" alt="Logo" width="45" height="35" class="d-inline-block align-text-top" alt="logosementara">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mx-auto mb-2 mb-lg-0 ps-5">
      <form class="d-flex my-auto ps-5" role="search">
        <input class="form-control " type="search" placeholder="Search" aria-label="Search" style="border-radius: 15px 0px 0px 15px; width:300px; border:none; font-size:16px;">
        <button class="btn" type="submit" style="border-radius: 0px 20px 20px 0px; background-color: white; height:40px" >
          <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
          <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"/></svg></i>
        </button>
      </form>       
      </ul>
      
      <div class="logres">
      <!-- <a class=" btn rounded-pill fw-semibold me-2 button1" href="register.php" role="button" style="background-color:white; color:#0AD1C8; box-shadow: 0px 0px 3px 4px rgba(10, 10, 10, 0.1);">Daftar</a>
      <a class=" btn rounded-pill fw-semibold button2" href="login.php" role="button" style="background-color:#0AD1C8; color:white; box-shadow: 0px 0px 3px 4px rgba(10, 10, 10, 0.1);">Masuk</a> -->
      <a href="register.php" class="button1 fw-semibold d-inline-block me-3 px-4 py-1 rounded-4">Daftar</a>
      <a href="login.php" class="button2 fw-semibold d-inline-block px-4 py-1 rounded-4">Masuk</a>

    </div>

    </div>
  </div>
</nav>

<!-- carousel -->
<div class="container">
  <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner rounded-4 ">
      <div class="carousel-item active" data-bs-interval="1000">
        <img src="assets/img/c.png" class="d-block w-100 img-fluid" alt="...">
      </div>
      <div class="carousel-item" data-bs-interval="1000">
        <img src="assets/img/bc2bfe6d-781e-4b39-a518-c680ede3b10c.jpg" class="d-block w-100 img-fluid" alt="...">
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
</div>
<!-- carousel -->

<!-- kategori -->
      <div class="container my-5">
        <div class="row">
          <div class="col-lg-3 col-sm-6 position-relative py-3">
            <a href="#">
              <img src="assets/img/cat/1.jpg" alt="" class="img-fluid rounded h-100"> 
              <p class="text-center position-absolute bottom-0 start-50 translate-middle fw-bold text-white" style="top:83%;">gambar 1</p>
            </a>
          </div>
          <div class="col-lg-3 col-sm-6 position-relative py-3">
            <a href="#">
              <img src="assets/img/cat/2.jpeg" alt="" class="img-fluid rounded h-100">      
              <p class="text-center position-absolute bottom-0 start-50 translate-middle fw-bold text-white" style="top:83%;">gambar 2</p>
            </a>
          </div>
          <div class="col-lg-3 col-sm-6 position-relative py-3">
            <a href="#">
              <img src="assets/img/cat/3.jpg" alt="" class="img-fluid rounded h-100">      
              <p class="text-center position-absolute bottom-0 start-50 translate-middle fw-bold text-white" style="top:83%;">gambar 3</p>
            </a>
          </div>
          <div class="col-lg-3 col-sm-6 position-relative py-3">
            <a href="#">
              <img src="assets/img/cat/4.jpg" alt="" class="img-fluid rounded h-100">      
              <p class="text-center position-absolute bottom-0 start-50 translate-middle fw-bold text-white" style="top:83%;">gambar 4</p>
            </a>
          </div>
        </div>
      </div>
      <!-- kategori -->

      <!-- inspirasi -->
<div class="container">
  <h1 class="text-center mb-4">Inspirasi Foto</h1>
  <div class="row row-cols-3 row-cols-md-3 row-cols-sm-2">

    <div class="col-md-4">
      <div class="card mb-3">
        <img src="assets/img/cat/2.jpeg" class="card-img-top img-fluid" alt="...">
        <div class="card-body">
          <div class="row">
          <div class="col-7">
            <img src="assets/img/logo.png" class="img-rounded" width="30" height="30">
            <span>Nama Kamu</span>
            </div>
            <div class="col-5  ">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width='20px' height='20px' class=""><path d="M225.8 468.2l-2.5-2.3L48.1 303.2C17.4 274.7 0 234.7 0 192.8v-3.3c0-70.4 50-130.8 119.2-144C158.6 37.9 198.9 47 231 69.6c9 6.4 17.4 13.8 25 22.3c4.2-4.8 8.7-9.2 13.5-13.3c3.7-3.2 7.5-6.2 11.5-9c0 0 0 0 0 0C313.1 47 353.4 37.9 392.8 45.4C462 58.6 512 119.1 512 189.5v3.3c0 41.9-17.4 81.9-48.1 110.4L288.7 465.9l-2.5 2.3c-8.2 7.6-19 11.9-30.2 11.9s-22-4.2-30.2-11.9zM239.1 145c-.4-.3-.7-.7-1-1.1l-17.8-20c0 0-.1-.1-.1-.1c0 0 0 0 0 0c-23.1-25.9-58-37.7-92-31.2C81.6 101.5 48 142.1 48 189.5v3.3c0 28.5 11.9 55.8 32.8 75.2L256 430.7 431.2 268c20.9-19.4 32.8-46.7 32.8-75.2v-3.3c0-47.3-33.6-88-80.1-96.9c-34-6.5-69 5.4-92 31.2c0 0 0 0-.1 .1s0 0-.1 .1l-17.8 20c-.3 .4-.7 .7-1 1.1c-4.5 4.5-10.6 7-16.9 7s-12.4-2.5-16.9-7z"/></svg>
              <span class="ms-1 me-2">200</span>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width='20px' hieght='20px'><path d="M123.6 391.3c12.9-9.4 29.6-11.8 44.6-6.4c26.5 9.6 56.2 15.1 87.8 15.1c124.7 0 208-80.5 208-160s-83.3-160-208-160S48 160.5 48 240c0 32 12.4 62.8 35.7 89.2c8.6 9.7 12.8 22.5 11.8 35.5c-1.4 18.1-5.7 34.7-11.3 49.4c17-7.9 31.1-16.7 39.4-22.7zM21.2 431.9c1.8-2.7 3.5-5.4 5.1-8.1c10-16.6 19.5-38.4 21.4-62.9C17.7 326.8 0 285.1 0 240C0 125.1 114.6 32 256 32s256 93.1 256 208s-114.6 208-256 208c-37.1 0-72.3-6.4-104.1-17.9c-11.9 8.7-31.3 20.6-54.3 30.6c-15.1 6.6-32.3 12.6-50.1 16.1c-.8 .2-1.6 .3-2.4 .5c-4.4 .8-8.7 1.5-13.2 1.9c-.2 0-.5 .1-.7 .1c-5.1 .5-10.2 .8-15.3 .8c-6.5 0-12.3-3.9-14.8-9.9c-2.5-6-1.1-12.8 3.4-17.4c4.1-4.2 7.8-8.7 11.3-13.5c1.7-2.3 3.3-4.6 4.8-6.9c.1-.2 .2-.3 .3-.5z"/></svg>
            <span class="ms-1">200</span>
            </div>
            </div>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card mb-3">
        <img src="assets/img/cat/2.jpeg" class="card-img-top img-fluid" alt="...">
        <div class="card-body">
          <div class="row">
          <div class="col-7">
            <img src="assets/img/logo.png" class="img-rounded" width="30" height="30">
            <span>Nama Kamu</span>
            </div>
            <div class="col-5  ">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width='20px' height='20px' class=""><path d="M225.8 468.2l-2.5-2.3L48.1 303.2C17.4 274.7 0 234.7 0 192.8v-3.3c0-70.4 50-130.8 119.2-144C158.6 37.9 198.9 47 231 69.6c9 6.4 17.4 13.8 25 22.3c4.2-4.8 8.7-9.2 13.5-13.3c3.7-3.2 7.5-6.2 11.5-9c0 0 0 0 0 0C313.1 47 353.4 37.9 392.8 45.4C462 58.6 512 119.1 512 189.5v3.3c0 41.9-17.4 81.9-48.1 110.4L288.7 465.9l-2.5 2.3c-8.2 7.6-19 11.9-30.2 11.9s-22-4.2-30.2-11.9zM239.1 145c-.4-.3-.7-.7-1-1.1l-17.8-20c0 0-.1-.1-.1-.1c0 0 0 0 0 0c-23.1-25.9-58-37.7-92-31.2C81.6 101.5 48 142.1 48 189.5v3.3c0 28.5 11.9 55.8 32.8 75.2L256 430.7 431.2 268c20.9-19.4 32.8-46.7 32.8-75.2v-3.3c0-47.3-33.6-88-80.1-96.9c-34-6.5-69 5.4-92 31.2c0 0 0 0-.1 .1s0 0-.1 .1l-17.8 20c-.3 .4-.7 .7-1 1.1c-4.5 4.5-10.6 7-16.9 7s-12.4-2.5-16.9-7z"/></svg>
              <span class="ms-1 me-2">200</span>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width='20px' hieght='20px'><path d="M123.6 391.3c12.9-9.4 29.6-11.8 44.6-6.4c26.5 9.6 56.2 15.1 87.8 15.1c124.7 0 208-80.5 208-160s-83.3-160-208-160S48 160.5 48 240c0 32 12.4 62.8 35.7 89.2c8.6 9.7 12.8 22.5 11.8 35.5c-1.4 18.1-5.7 34.7-11.3 49.4c17-7.9 31.1-16.7 39.4-22.7zM21.2 431.9c1.8-2.7 3.5-5.4 5.1-8.1c10-16.6 19.5-38.4 21.4-62.9C17.7 326.8 0 285.1 0 240C0 125.1 114.6 32 256 32s256 93.1 256 208s-114.6 208-256 208c-37.1 0-72.3-6.4-104.1-17.9c-11.9 8.7-31.3 20.6-54.3 30.6c-15.1 6.6-32.3 12.6-50.1 16.1c-.8 .2-1.6 .3-2.4 .5c-4.4 .8-8.7 1.5-13.2 1.9c-.2 0-.5 .1-.7 .1c-5.1 .5-10.2 .8-15.3 .8c-6.5 0-12.3-3.9-14.8-9.9c-2.5-6-1.1-12.8 3.4-17.4c4.1-4.2 7.8-8.7 11.3-13.5c1.7-2.3 3.3-4.6 4.8-6.9c.1-.2 .2-.3 .3-.5z"/></svg>
            <span class="ms-1">200</span>
            </div>
            </div>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card mb-3">
        <img src="assets/img/cat/2.jpeg" class="card-img-top img-fluid" alt="...">
        <div class="card-body">
          <div class="row">
          <div class="col-7">
            <img src="assets/img/logo.png" class="img-rounded" width="30" height="30">
            <span>Nama Kamu</span>
            </div>
            <div class="col-5  ">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width='20px' height='20px' class=""><path d="M225.8 468.2l-2.5-2.3L48.1 303.2C17.4 274.7 0 234.7 0 192.8v-3.3c0-70.4 50-130.8 119.2-144C158.6 37.9 198.9 47 231 69.6c9 6.4 17.4 13.8 25 22.3c4.2-4.8 8.7-9.2 13.5-13.3c3.7-3.2 7.5-6.2 11.5-9c0 0 0 0 0 0C313.1 47 353.4 37.9 392.8 45.4C462 58.6 512 119.1 512 189.5v3.3c0 41.9-17.4 81.9-48.1 110.4L288.7 465.9l-2.5 2.3c-8.2 7.6-19 11.9-30.2 11.9s-22-4.2-30.2-11.9zM239.1 145c-.4-.3-.7-.7-1-1.1l-17.8-20c0 0-.1-.1-.1-.1c0 0 0 0 0 0c-23.1-25.9-58-37.7-92-31.2C81.6 101.5 48 142.1 48 189.5v3.3c0 28.5 11.9 55.8 32.8 75.2L256 430.7 431.2 268c20.9-19.4 32.8-46.7 32.8-75.2v-3.3c0-47.3-33.6-88-80.1-96.9c-34-6.5-69 5.4-92 31.2c0 0 0 0-.1 .1s0 0-.1 .1l-17.8 20c-.3 .4-.7 .7-1 1.1c-4.5 4.5-10.6 7-16.9 7s-12.4-2.5-16.9-7z"/></svg>
              <span class="ms-1 me-2">200</span>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width='20px' hieght='20px'><path d="M123.6 391.3c12.9-9.4 29.6-11.8 44.6-6.4c26.5 9.6 56.2 15.1 87.8 15.1c124.7 0 208-80.5 208-160s-83.3-160-208-160S48 160.5 48 240c0 32 12.4 62.8 35.7 89.2c8.6 9.7 12.8 22.5 11.8 35.5c-1.4 18.1-5.7 34.7-11.3 49.4c17-7.9 31.1-16.7 39.4-22.7zM21.2 431.9c1.8-2.7 3.5-5.4 5.1-8.1c10-16.6 19.5-38.4 21.4-62.9C17.7 326.8 0 285.1 0 240C0 125.1 114.6 32 256 32s256 93.1 256 208s-114.6 208-256 208c-37.1 0-72.3-6.4-104.1-17.9c-11.9 8.7-31.3 20.6-54.3 30.6c-15.1 6.6-32.3 12.6-50.1 16.1c-.8 .2-1.6 .3-2.4 .5c-4.4 .8-8.7 1.5-13.2 1.9c-.2 0-.5 .1-.7 .1c-5.1 .5-10.2 .8-15.3 .8c-6.5 0-12.3-3.9-14.8-9.9c-2.5-6-1.1-12.8 3.4-17.4c4.1-4.2 7.8-8.7 11.3-13.5c1.7-2.3 3.3-4.6 4.8-6.9c.1-.2 .2-.3 .3-.5z"/></svg>
            <span class="ms-1">200</span>
            </div>
            </div>
        </div>
      </div>
    </div>

  </div>
</div>
<!-- inspirasi -->

<div class="container-fluid bg-secondary">
  <div class="text-center">
    <h1 class="pt-3">Join To RxGallery's Family</h1>
    <a href="register.php" type="button" class="btnjoin p-2 rounded-2 mt-3">Gabung Sekarang</a>
    <div class="row pt-1">
      <div class="col-md-4 col-sm-10 text-center mx-auto my-auto">
        <img src="assets/img/Teks paragraf Anda.png" alt="" class="" width="55%" >
        <!-- <p class="fs-1 fw-bold lead text-white" style="padding-top: -5rem;">Gallery</p> -->
      </div>
      <div class="col-md-4 col-sm-10 text-center mx-auto my-auto">
        <h2>Our Contact</h2>
        <p><h3>SMKN 9 Medan Jl. Patriot</h3> 
          
        </p>
      </div>
      <div class="col-md-4 col-sm-10 text-center mx-auto my-auto">
        <img src="assets/img/stamp1.png" alt="" width="30%">
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
