<?php
session_start();
include '../config/koneksi.php';
if ($_SESSION['status'] != 'login') {
    echo "<script>
    alert('Anda belum Login!');
    location.href='../index.php';
    </script>";
}
?>
<?php

$userid = $_SESSION['userid'];
// Ambil data pengguna dari database berdasarkan userid
$sql = mysqli_query($koneksi, "SELECT * FROM user WHERE userid='$userid'");
if (mysqli_num_rows($sql) > 0) {
    $row = mysqli_fetch_assoc($sql);
    $username = $row['username'];
    $namalengkap = $row['namalengkap'];
    $email = $row['email'];
    $alamat = $row['alamat'];
} else {
    // Jika data pengguna tidak ditemukan, redirect ke halaman login
    echo "<script>
    alert('Data pengguna tidak ditemukan!');
    location.href='../index.php';
    </script>";
    exit();
}
?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=initial-scale=1.0">
    <!-- googefonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <!-- googefonts -->
    <!-- css -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <title>Document</title>
</head>

<body>
    <!-- navbar -->
    <nav class="navbar navbar-expand-lg mb-5 shadow-lg">
        <div class="container">
            <a class="navbar-brand" href="#">
                <p class="my-auto">Rx Galleria</p>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto mb-2 mb-lg-0 pe-5">
                    <form class="d-flex my-auto ps-5 me-5" role="search">
                        <input class="form-control " type="search" placeholder="Search" aria-label="Search" style="border-radius: 15px 0px 0px 15px; width:300px; border:none; font-size:16px;">
                        <button class="btn" type="submit" style="border-radius: 0px 20px 20px 0px; background-color: white; height:40px">
                            <svg xmlns="http://www.w3.org/2000/svg" width="19" height="17" fill="currentColor" class="bi bi-search mb-1 me-1" viewBox="0 0 16 16">
                                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0" />
                            </svg></i>
                        </button>
                    </form>
                </ul>
                <div class="dropdown">
                    <img src="../assets/img/bc2bfe6d-781e-4b39-a518-c680ede3b10c.jpg" class="img-fluid rounded-circle" onclick="toggleDropdown()" style="cursor:pointer;">
                    <div id="profileDropdown" class="dropdown-menu">
                        <a href="index.php" class="dropdown-item">Galeri</a>
                        <a href="home.php" class="dropdown-item">Home</a>
                        <a href="profil.php" class="dropdown-item">Profil</a>
                        <a href="album.php" class="dropdown-item">Album</a>
                        <a href="foto.php" class="dropdown-item">Foto</a>
                        <a href="../config/aksi-logout.php" class="dropdown-item">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <!-- navbar -->

    <div class="container">
        <div class="row mx-auto justify-content-center">
            <div class="profildata col-md-4 mx-auto rounded-3">
                <h2 class="text-center mt-3">Hallo, <?php echo $username ?></h2><br>
                <h5>Nama : <?php echo $namalengkap; ?> </h5><br>
                <h5>Email : <?php echo $email; ?></h5><br>
                <h5>Alamat : <?php echo $alamat; ?> </h5><br>
            </div>
            <div class="profildata col-md-7 mx-auto rounded-3">
                <form action="../config/update_profile.php" method="POST">
                    <div class="mb-3">
                        <label for="namalengkap" class="form-label mt-3 fw-medium">Nama Lengkap</label>
                        <input type="text" class="form-control" id="namalengkap" name="namalengkap" value="<?php echo $namalengkap; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label fw-medium">Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="alamat" class="form-label fw-medium">Alamat</label>
                        <textarea class="form-control" id="alamat" name="alamat" rows="3"><?php echo $alamat; ?></textarea>
                    </div>
                    <button type="submit" class="btnprofil p-2 rounded-3 fw-medium">Simpan Perubahan</button>
                </form>
            </div>
        </div>
    </div>
    </div>
    <footer class="text-center border-top pb-1 pt-4 bg-light fixed-bottom">
		<p> Rx Galleria &copy; Reserved</p>
	</footer>
    <script>
        function toggleDropdown() {
            var dropdownMenu = document.getElementById("profileDropdown");
            dropdownMenu.classList.toggle("show");
        }
    </script>
</body>

</html>