<?php
session_start();
$userid = $_SESSION['userid'];
include '../config/koneksi.php';
if ($_SESSION['status'] != 'login') {
	echo "<script>
    alert('Anda belum Login!');
    location.href='../index.php';
    </script>";
}
?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>WEBSITE GALERI FOTO</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
	<link rel="stylesheet" href="../assets/css/style.css">
	<!-- googefonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
	<!-- googefonts -->
</head>

<body>
	<!-- navbar -->
	<nav class="navbar navbar-expand-lg mb-5 shadow-lg">
		<div class="container">
			<a class="navbar-brand" href="#">
				<p class="my-auto">Rx Galleria</p>
			</a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav mx-auto mb-2 mb-lg-0 pe-5">
					<form class="d-flex my-auto ps-5 me-5" role="search">
						<input class="form-control " type="search" placeholder="Search" aria-label="Search" style="border-radius: 15px 0px 0px 15px; width:300px; border:none; font-size:16px;">
						<button class="btn" type="submit" style="border-radius: 0px 20px 20px 0px; background-color: white; height:40px">
							<svg xmlns="http://www.w3.org/2000/svg" width="19" height="17" fill="currentColor" class="bi bi-search mb-1 me-1" viewBox="0 0 16 16">
								<path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0" />
							</svg></i>
						</button>
					</form>
				</ul>
				<div class="dropdown">
					<img src="../assets/img/bc2bfe6d-781e-4b39-a518-c680ede3b10c.jpg" class="img-fluid rounded-circle" onclick="toggleDropdown()" style="cursor:pointer;">
					<div id="profileDropdown" class="dropdown-menu">
						<a href="index.php" class="dropdown-item">Galeri</a>
						<a href="home.php" class="dropdown-item">Home</a>
						<a href="profil.php" class="dropdown-item">Profil</a>
						<a href="album.php" class="dropdown-item">Album</a>
						<a href="foto.php" class="dropdown-item">Foto</a>
						<a href="../config/aksi-logout.php" class="dropdown-item">Logout</a>
					</div>
				</div>
			</div>
		</div>
	</nav>
	<!-- navbar -->

	<div class="container mt-3">
		Album:
		<?php
		$album = mysqli_query($koneksi, "SELECT * FROM album WHERE userid='$userid'");
		while ($row = mysqli_fetch_array($album)) { ?>
			<a href="home.php?albumid=<?php echo $row['albumid'] ?>" class="btn btn-outline-primary"><?php echo  $row['namaalbum'] ?></a>


		<?php } ?>

		<div class="row">
			<?php
			if (isset($_GET['albumid'])) {
				$albumid = $_GET['albumid'];
				$query = mysqli_query($koneksi, "SELECT * FROM  foto WHERE userid='$userid' AND albumid='$albumid'");
				while ($data = mysqli_fetch_array($query)) { ?>

					<div class="col-md-3 mt-2">
						<div class="card">
							<img src="../assets/image/<?php echo $data['lokasifile'] ?>" class="card-img-top" title="<?php echo $data['judulfoto'] ?>" style="height : 12rem;">
							<div class="card-footer text-center">

								<?php
								$fotoid = $data['fotoid'];
								$ceksuka = mysqli_query($koneksi, "SELECT * FROM likefoto WHERE fotoid='$fotoid' AND userid='$userid'");
								if (mysqli_num_rows($ceksuka) == 1) { ?>
									<a href="../config/proses-like.php?fotoid=<?php echo $data['fotoid'] ?>" type="submit" name="batalsuka"><i class="fa-regular fa-heart"></i></a>

								<?php } else { ?>
									<a href="../config/proses-like.php?fotoid=<?php echo $data['fotoid'] ?>" type="submit" name="suka"><i class="fa-regular fa-heart" style="color:red;"></i></a>

								<?php }
								$like = mysqli_query($koneksi, "SELECT * FROM likefoto WHERE fotoid='$fotoid'");
								echo mysqli_num_rows($like) . ' Suka';
								?>
								<a href=""><i class="fa-regular fa-comment"></i></a> KOMENTAR
							</div>
						</div>
					</div>
				<?php }
			} else {

				$query = mysqli_query($koneksi, "SELECT * FROM foto WHERE userid='$userid'");
				while ($data = mysqli_fetch_array($query)) {
				?>
					<div class="col-md-3 mt-2">
						<div class="card">
							<img src="../assets/image/<?php echo $data['lokasifile'] ?>" class="card-img-top" title="<?php echo $data['judulfoto'] ?>" style="height : 12rem;">
							<div class="card-footer text-center">

								<?php
								$fotoid = $data['fotoid'];
								$ceksuka = mysqli_query($koneksi, "SELECT * FROM likefoto WHERE fotoid='$fotoid' AND userid='$userid'");
								if (mysqli_num_rows($ceksuka) == 1) { ?>
									<a href="../config/proses-like.php?fotoid=<?php echo $data['fotoid'] ?>" type="submit" name="batalsuka"><i class="fa-regular fa-heart"></i></a>

								<?php } else { ?>
									<a href="../config/proses-like.php?fotoid=<?php echo $data['fotoid'] ?>" type="submit" name="suka"><i class="fa-regular fa-heart"></i></a>

								<?php }
								$like = mysqli_query($koneksi, "SELECT * FROM likefoto WHERE fotoid='$fotoid'");
								echo mysqli_num_rows($like) . ' Suka';
								?>
								<a href=""><i class="fa-regular fa-comment"></i></a> KOMENTAR
							</div>
						</div>
					</div>
			<?php }
			} ?>
		</div>
	</div>
	<footer class="text-center border-top pb-1 pt-4 bg-light fixed-bottom">
		<p> Rx Galleria &copy; Reserved</p>
	</footer>
	<script>
		function toggleDropdown() {
			var dropdownMenu = document.getElementById("profileDropdown");
			dropdownMenu.classList.toggle("show");
		}
	</script>
	<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
</body>

</html>