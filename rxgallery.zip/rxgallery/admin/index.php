<?php
session_start();
$userid = $_SESSION['userid'];
include '../config/koneksi.php';
if ($_SESSION['status'] != 'login') {
	echo "<script>
    alert('Anda belum Login!');
    location.href='../index.php';
    </script>";
}
?>
<?php

$userid = $_SESSION['userid'];
// Ambil data pengguna dari database berdasarkan userid
$sql = mysqli_query($koneksi, "SELECT * FROM user WHERE userid='$userid'");
if (mysqli_num_rows($sql) > 0) {
    $row = mysqli_fetch_assoc($sql);
    $username = $row['username'];
    $namalengkap = $row['namalengkap'];
    $email = $row['email'];
    $alamat = $row['alamat'];
} else {
    // Jika data pengguna tidak ditemukan, redirect ke halaman login
    echo "<script>
    alert('Data pengguna tidak ditemukan!');
    location.href='../index.php';
    </script>";
    exit();
}
?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>WEBSITE GALERI FOTO</title>
	<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
	<link rel="stylesheet" href="../assets/css/style.css">
	<!-- google fonts -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Modern+Antiqua&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Princess+Sofia&display=swap" rel="stylesheet">
	<!-- google fonts -->
</head>

<body>
	<!-- navbar -->
	<nav class="navbar navbar-expand-lg mb-5 shadow-lg">
		<div class="container">
			<a class="navbar-brand" href="#">
				<p class="my-auto">Rx Galleria</p>
			</a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav mx-auto mb-2 mb-lg-0 pe-5">
					<form class="d-flex my-auto ps-5 me-5" role="search">
						<input class="form-control " type="search" placeholder="Search" aria-label="Search" style="border-radius: 15px 0px 0px 15px; width:300px; border:none; font-size:16px;">
						<button class="btn" type="submit" style="border-radius: 0px 20px 20px 0px; background-color: white; height:40px">
							<svg xmlns="http://www.w3.org/2000/svg" width="19" height="17" fill="currentColor" class="bi bi-search mb-1 me-1" viewBox="0 0 16 16">
								<path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0" />
							</svg></i>
						</button>
					</form>
				</ul>
				<div class="dropdown">
					<img src="../assets/img/bc2bfe6d-781e-4b39-a518-c680ede3b10c.jpg" class="img-fluid rounded-circle" onclick="toggleDropdown()" style="cursor:pointer;">
					<div id="profileDropdown" class="dropdown-menu">
						<a href="index.php" class="dropdown-item">Galeri</a>
						<a href="home.php" class="dropdown-item">Home</a>
						<a href="profil.php" class="dropdown-item">Profil</a>
						<a href="album.php" class="dropdown-item">Album</a>
						<a href="foto.php" class="dropdown-item">Foto</a>
						<a href="../config/aksi-logout.php" class="dropdown-item">Logout</a>
					</div>
				</div>
			</div>
		</div>
	</nav>
	<!-- navbar -->

	<div class="container mt-2">
		<div class="row">
			<?php
			$query = mysqli_query($koneksi, "SELECT * FROM foto INNER JOIN user ON foto.userid=user.userid INNER JOIN album ON foto.albumid=album.albumid");
			while ($data = mysqli_fetch_array($query)) {
			?>
				<div class="col-3 ">
					<a type="button" data-bs-toggle="modal" data-bs-target="#komentar<?php echo $data['fotoid'] ?>">
						<div class="card mb-2">
							<img src="../assets/image/<?php echo $data['lokasifile'] ?>" class="card-img-top rounded-2 " title="<?php echo $data['judulfoto'] ?>" style="height:17rem;">
							<div class="container bg-light rounded-bottom d-flex justify-content-around" style="margin-top: -5px;">
								<div class="row">
									<div class="col">
										<p style="margin-right: 8rem;"><?php echo $username ?></p>
										<?php
										$fotoid = $data['fotoid'];
										$ceksuka = mysqli_query($koneksi, "SELECT * FROM likefoto WHERE fotoid='$fotoid' AND userid='$userid'");
										if (mysqli_num_rows($ceksuka) == 1) { ?>
											<a href="../config/proses-like.php?fotoid=<?php echo $data['fotoid'] ?>" type="submit" name="batalsuka"><i class="fa-solid fa-heart "></i></a>

										<?php } else { ?>
											<a href="../config/proses-like.php?fotoid=<?php echo $data['fotoid'] ?>" type="submit" name="suka"><i class="fa-regular fa-heart"></i></a>

										<?php }
										$like = mysqli_query($koneksi, "SELECT * FROM likefoto WHERE fotoid='$fotoid'");
										echo mysqli_num_rows($like);
										?>
										<a href="" data-bs-toggle="modal" data-bs-target="#komentar<?php echo $data['fotoid'] ?>"><i class="fa-regular fa-comment ms-2"></i></a>
										<?php
										$jmlkomen = mysqli_query($koneksi, "SELECT * FROM komentarfoto WHERE fotoid='$fotoid'");
										echo mysqli_num_rows($jmlkomen);
										?>
									</div>
								</div>
							</div>

						</div>
					</a>

					<div class="modal fade" id="komentar<?php echo $data['fotoid'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
						<div class="modal-dialog modal-xl">
							<div class="modal-content">
								<div class="modal-body">
									<div class="row">
										<div class="col-md-8">
											<img src="../assets/image/<?php echo $data['lokasifile'] ?>" class="card-img-top" title="<?php echo $data['judulfoto'] ?>">
										</div>
										<div class="col-md-4">
											<div class="m-2">
												<div class="overflow-auto">
													<div class="sticky-top">
														<strong><?php echo $data['judulfoto'] ?></strong><br>
														<span class="badge bg-secondary"><?php echo $data['namalengkap'] ?></span>
														<span class="badge bg-secondary"><?php echo $data['tanggalunggah'] ?></span>
														<span class="badge bg-primary"><?php echo $data['namaalbum'] ?></span>
													</div>
													<hr>
													<p align="left"> <span class="fw-medium"> Deskripsi</span> <br>
														<?php echo $data['deskripsifoto'] ?>
													</p>
													<hr>
													<?php
													$fotoid = $data['fotoid'];
													$komentar = mysqli_query($koneksi, "SELECT * FROM komentarfoto INNER JOIN user ON komentarfoto.userid=user.userid WHERE komentarfoto.fotoid='$fotoid'");
													while ($row = mysqli_fetch_array($komentar)) {
													?>
														<p align="left">
															<strong><?php echo $row['namalengkap'] ?></strong>
															<?php echo $row['isikomentar'] ?>
															<button class="btn delete-comment" data-komentarid="<?php echo $row['komentarid'] ?>"><i class="fa-solid fa-trash"></i></button>
														</p>
													<?php } ?>
													<hr>
													<div class="sticky-bottom">
														<form action="../config/proses-komentar.php" method="POST">
															<div class="input-group">
																<input type="hidden" name="fotoid" value="<?php echo $data['fotoid'] ?>">
																<input type="text" name="isikomentar" class="form-control" placeholder="Tambah Komentar"> 
																<div class="input-group-prepend">
																	<button type="submit" name="kirimkomentar" class="btn btn-outline-primary">Kirim</button>
																</div>
															</div>
														</form>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php } ?>
		</div>
	</div>



	<footer class="footer text-center pb-1 pt-4 fixed-bottom">
		<p> Rx Galleria &copy; Reserved</p>
	</footer>


	<script>
		function toggleDropdown() {
			var dropdownMenu = document.getElementById("profileDropdown");
			dropdownMenu.classList.toggle("show");
		}
	</script>
	<!-- Tambahkan script JavaScript untuk menangani penghapusan komentar -->
<script>
    // Ambil semua elemen dengan kelas .delete-comment
    var deleteButtons = document.querySelectorAll('.delete-comment');

    // Loop melalui setiap tombol dan tambahkan event listener
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            // Ambil ID komentar dari atribut data-komentarid
            var komentarId = button.getAttribute('data-komentarid');

            // Kirim permintaan penghapusan komentar ke server menggunakan AJAX
            var xhr = new XMLHttpRequest();
            xhr.open('POST', '../config/hapus_komentar.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (xhr.status == 200) {
                    // Tindakan setelah komentar dihapus, seperti memuat ulang halaman atau memperbarui daftar komentar
                    console.log('Komentar berhasil dihapus');
                    // Hapus elemen komentar dari tampilan
                    button.parentNode.remove(); // Hapus parent dari tombol yang dihapus
                } else {
                    console.error('Terjadi kesalahan saat menghapus komentar');
                }
            };
            xhr.send('komentarid=' + komentarId);
        });
    });
</script>

	<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
</body>

</html>